# ravn-home-common

Capa común de `$HOME` para la workstation ravn, derivada de la configuración base de `robert-flo/niri-dotfiles`.

Está diseñada para ser instalada en el sistema bajo `/usr/share/ravn/common` (vía paquete pacman `ravn-home-common` distribuido por `pj-omarchy`). El `$HOME` del usuario se mantiene limpio y mínimo: los programas con soporte nativo de modularidad cargan la configuración común mediante `source`, `include` o `import`, mientras que los programas sin soporte de include son enlazados de manera idempotente mediante la herramienta `ravn-home-sync`.

---

## 📂 Mapeo de Archivos: Qué archivo de `$HOME` carga qué

### 1. Programas con soporte nativo de modularidad (`source` / `include` / `import`)

Estos archivos se configuran en el repositorio de dotfiles del perfil del usuario (o dotbare) como pequeños *loaders* que incorporan la base común y permiten añadir personalizaciones locales:

| Programa | Archivo en `$HOME` | Método de Carga | Archivo Base en `/usr/share/ravn/common` | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| **Bash** | `~/.bashrc` | `source` | `/usr/share/ravn/common/bash/rc` | Bootstrap Omarchy, CURSOR_API_KEY, wrappers `try`, aliases comunes |
| **Fish** | `~/.config/fish/config.fish` | `source` | `/usr/share/ravn/common/fish/config.fish` | Tema Clavis, wrappers `try`, variables interactivas |
| **Alacritty** | `~/.config/alacritty/alacritty.toml` | `general.import` | `/usr/share/ravn/common/alacritty/alacritty.toml` | Fuente JetBrainsMono, keybindings terminal, tema y paddings |
| **MPV (Config)** | `~/.config/mpv/mpv.conf` | `include` | `/usr/share/ravn/common/mpv/mpv.conf` | Backend vulkan/gpu-next, vaapi, sync, uosc titlebar |

#### Ejemplos de cargadores en `$HOME`:

- **`~/.bashrc`**:
  ```bash
  [[ -r /usr/share/ravn/common/bash/rc ]] && source /usr/share/ravn/common/bash/rc

  # Overrides locales del usuario:
  ```

- **`~/.config/fish/config.fish`**:
  ```fish
  test -r /usr/share/ravn/common/fish/config.fish; and source /usr/share/ravn/common/fish/config.fish

  # Overrides locales del usuario:
  ```

- **`~/.config/alacritty/alacritty.toml`**:
  ```toml
  general.import = [
    "/usr/share/ravn/common/alacritty/alacritty.toml"
  ]

  # Overrides locales del usuario:
  ```

- **`~/.config/mpv/mpv.conf`**:
  ```ini
  include=/usr/share/ravn/common/mpv/mpv.conf

  # Overrides locales del usuario:
  ```

---

### 2. Programas sin soporte de include (gestionados por `ravn-home-sync`)

Los programas cuyos formatos de configuración no admiten `include` o directivas equivalentes son enlazados simbólicamente desde `$HOME` hacia `/usr/share/ravn/common` mediante `ravn-home-sync`:

| Componente | Enlace en `$HOME` | Destino en `/usr/share/ravn/common` |
| :--- | :--- | :--- |
| **fcitx5** | `~/.config/fcitx5/conf/classicui.conf` | `/usr/share/ravn/common/fcitx5/conf/classicui.conf` |
| **GTK 3.0** | `~/.config/gtk-3.0/settings.ini` | `/usr/share/ravn/common/gtk-3.0/settings.ini` |
| **GTK 4.0** | `~/.config/gtk-4.0/settings.ini` | `/usr/share/ravn/common/gtk-4.0/settings.ini` |
| **GTK 4.0** | `~/.config/gtk-4.0/gtk.css` | `/usr/share/ravn/common/gtk-4.0/gtk.css` |
| **GTK 4.0** | `~/.config/gtk-4.0/gtk-dark.css` | `/usr/share/ravn/common/gtk-4.0/gtk-dark.css` |
| **GTK 4.0** | `~/.config/gtk-4.0/gtk-Dark.css` | `/usr/share/ravn/common/gtk-4.0/gtk-Dark.css` |
| **GTK 4.0** | `~/.config/gtk-4.0/gtk-Light.css` | `/usr/share/ravn/common/gtk-4.0/gtk-Light.css` |
| **GTK 4.0** | `~/.config/gtk-4.0/assets` | `/usr/share/ravn/common/gtk-4.0/assets` |
| **GTK 4.0** | `~/.config/gtk-4.0/windows-assets` | `/usr/share/ravn/common/gtk-4.0/windows-assets` |
| **MPV (Keybindings)** | `~/.config/mpv/input.conf` | `/usr/share/ravn/common/mpv/input.conf` |
| **MPV (Fuentes UI)** | `~/.config/mpv/fonts` | `/usr/share/ravn/common/mpv/fonts` |
| **MPV (Opciones Script)** | `~/.config/mpv/script-opts` | `/usr/share/ravn/common/mpv/script-opts` |
| **MPV (Scripts y uosc)** | `~/.config/mpv/scripts` | `/usr/share/ravn/common/mpv/scripts` |

---

## 🛠️ Herramienta `ravn-home-sync`

La herramienta `ravn-home-sync` es un script ejecutable e idempotente instalado en `/usr/share/ravn/common/bin/ravn-home-sync`.

### Características
- **Idempotencia estricta:** Ejecutarlo una o cien veces produce el mismo resultado sin modificaciones repetitivas ni errores.
- **Detección inteligente:** Si el enlace simbólico ya apunta al destino correcto, no realiza ninguna acción.
- **Protección de datos:** Si existe un archivo o directorio en conflicto, no lo sobreescribe a menos que se especifique `--force`, en cuyo caso genera un respaldo con marca de tiempo (`.bak-YYYYMMDDHHMMSS`).
- **Skeletons opcionales (`-k, --skeletons`):** Puede generar los archivos cargadores mínimos para bash, fish, alacritty y mpv si aún no existen en el perfil.

### Uso
```bash
/usr/share/ravn/common/bin/ravn-home-sync [OPCIONES]

Opciones:
  -t, --target DIR     Directorio base destino (por defecto: $HOME)
  -s, --source DIR     Directorio base común (por defecto: /usr/share/ravn/common)
  -f, --force          Reemplaza archivos en conflicto creando respaldo .bak
  -k, --skeletons      Crea archivos cargadores mínimos (.bashrc, etc.) si no existen
  -n, --dry-run        Modo simulación (sin realizar cambios)
  -v, --verbose        Muestra todas las comprobaciones
  -h, --help           Muestra la ayuda
```

---

## 🧪 Pruebas Automatizadas

El repositorio incluye una suite de pruebas en `tests/test_sync.sh` que valida:
- Sintaxis de todos los scripts (`bash -n`).
- Simulación `dry-run` sin efectos secundarios.
- Creación de enlaces simbólicos en un directorio aislado.
- Idempotencia absoluta (segunda corrida = 0 modificaciones).
- Respaldo automático ante conflictos con `--force`.
